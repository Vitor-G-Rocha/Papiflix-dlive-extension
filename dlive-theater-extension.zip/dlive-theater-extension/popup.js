// popup.js v5

const app = document.getElementById('app');

async function sendMsg(tabId, msg) {
  return new Promise(resolve => {
    chrome.tabs.sendMessage(tabId, msg, res => {
      resolve(chrome.runtime.lastError ? null : res);
    });
  });
}

async function ensureContentScript(tabId) {
  const res = await sendMsg(tabId, { action: 'getStatus' });
  if (res !== null) return res;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    await new Promise(r => setTimeout(r, 350));
    return await sendMsg(tabId, { action: 'getStatus' });
  } catch (e) {
    return null;
  }
}

function render(isActive, diagData) {
  // 1. Injeta HTML
  app.innerHTML = `
    <div class="content">
      <div class="status-row">
        <span class="status-label">Status</span>
        <span class="badge ${isActive ? 'on' : 'off'}">
          ${isActive ? '● ATIVO' : '○ INATIVO'}
        </span>
      </div>
      <button class="btn ${isActive ? 'btn-deactivate' : 'btn-activate'}" id="toggle-btn">
        ${isActive ? '✕ DESATIVAR MODO TEATRO' : '▶ ATIVAR MODO TEATRO'}
      </button>
      <div class="divider"></div>      
    </div>
  `;

  // 2. Só depois de injetar o HTML, busca os elementos e adiciona listeners
  const toggleBtn = document.getElementById('toggle-btn');
  const diagBtn   = document.getElementById('diag-btn');

  if (toggleBtn) {
    toggleBtn.addEventListener('click', async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs[0]) return;
      const status = await ensureContentScript(tabs[0].id);
      if (status === null) {
        showError('Não foi possível conectar.<br>Recarregue a aba do DLive (F5) e tente novamente.');
        return;
      }
      const res = await sendMsg(tabs[0].id, { action: 'toggleTheater' });
      if (res) render(res.active);
    });
  }

  if (diagBtn) {
    diagBtn.addEventListener('click', async () => {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs[0]) return;
      const res = await sendMsg(tabs[0].id, { action: 'getDiagnostics' });
      render(isActive, res ?? { erro: 'Sem resposta. Recarregue a aba (F5).' });
    });
  }
}

function formatDiag(d) {
  return Object.entries(d).map(([k, v]) =>
    `<div><span class="key">${k}:</span> <span class="val">${String(v).slice(0, 130)}</span></div>`
  ).join('');
}

function showError(msg) {
  app.innerHTML = `<div style="padding:16px;font-size:12px;color:#f77;font-family:Inter,system-ui,sans-serif;line-height:1.7;">${msg}</div>`;
}

function renderNotDLive() {
  app.innerHTML = `
    <div class="not-dlive">
      <div class="icon">📺</div>
      <p>Acesse o <a href="https://dlive.tv/PapiflixOficial" target="_blank">Papiflix</a> e abra uma transmissão ao vivo para usar o modo teatro.</p>
    </div>
  `;
}

// Init
(async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab?.url?.includes('dlive.tv')) { renderNotDLive(); return; }
  const status = await ensureContentScript(tab.id);
  render(status?.active ?? false);
})();
