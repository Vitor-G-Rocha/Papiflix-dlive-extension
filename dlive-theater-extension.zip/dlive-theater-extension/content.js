// ============================================================
//  DLive Ultra Theater v3 — content.js
//  - Move elementos originais (não clona)
//  - Chat: containment rigoroso, sem quebrar estilos originais
//  - Corrige: imagens/links expandindo, texto invisível,
//    emotes/stickers preservados, input funcional
// ============================================================

(function () {
  'use strict';

  const STORAGE_KEY = 'dliveTheaterActive_v3';
  let theaterActive = false;
  let styleEl = null;
  let overlayEl = null;
  let exitBtn = null;
  let mutObserver = null;
  let retryTimer = null;
  let colorFixObserver = null;

  function log(...args) { console.log('[DLive Theater]', ...args); }

  function waitFor(fn, timeout = 12000, interval = 300) {
    return new Promise((resolve, reject) => {
      const t0 = Date.now();
      const tick = () => {
        const el = fn();
        if (el) return resolve(el);
        if (Date.now() - t0 > timeout) return reject(new Error('Timeout'));
        setTimeout(tick, interval);
      };
      tick();
    });
  }

  function findPlayerEl() {
    const video = document.querySelector('video');
    if (!video) return null;
    let el = video.parentElement;
    for (let i = 0; i < 8 && el && el !== document.body; i++) {
      const r = el.getBoundingClientRect();
      if (r.width > 400 && r.height > 200) return el;
      el = el.parentElement;
    }
    return video.parentElement;
  }

  function findChatEl() {
    const selectors = [
      '[class*="chat-box"]', '[class*="ChatBox"]', '[class*="chatbox"]',
      '[class*="lc-container"]', '[class*="live-chat"]', '[class*="LiveChat"]',
      '[class*="chat-room"]', '[class*="ChatRoom"]', '[class*="right-panel"]',
      '[class*="RightPanel"]', '[class*="chat-panel"]', '[class*="ChatPanel"]',
      'aside', 'iframe[src*="chat"]',
    ];
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        if (el && el.getBoundingClientRect().height > 200) {
          log('Chat via:', sel, el);
          return el;
        }
      } catch (_) {}
    }
    const playerEl = findPlayerEl();
    for (const div of document.querySelectorAll('div')) {
      const r = div.getBoundingClientRect();
      if (r.width > 100 && r.width < 500 && r.height > 400 && r.left > window.innerWidth * 0.55) {
        if (!playerEl || !playerEl.contains(div)) {
          log('Chat via fallback:', div);
          return div;
        }
      }
    }
    return null;
  }

  function injectCSS() {
    styleEl?.remove();
    styleEl = document.createElement('style');
    styleEl.id = 'dlive-theater-style';
    styleEl.textContent = `
      /* === DLive Ultra Theater v3 === */

      body.dlive-theater-mode > *:not(#dlive-theater-overlay):not(#dlive-theater-exit):not(#dlive-theater-notif) {
        visibility: hidden !important;
        pointer-events: none !important;
      }

      #dlive-theater-overlay {
        position: fixed !important;
        inset: 0 !important;
        z-index: 2147483000 !important;
        background: #0d0d0d !important;
        display: flex !important;
        align-items: stretch !important;
        visibility: visible !important;
        pointer-events: all !important;
      }

      /* ── Player slot ── */
      #dlive-theater-player-slot {
        flex: 1 1 auto !important;
        min-width: 0 !important;
        height: 100% !important;
        background: #000 !important;
        position: relative !important;
        overflow: hidden !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }
      #dlive-theater-player-slot [data-theater-player="true"] {
        position: absolute !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
      }
      #dlive-theater-player-slot video {
        width: 100% !important;
        height: 100% !important;
        object-fit: contain !important;
        background: #000 !important;
        display: block !important;
      }

      /* ── Chat slot ──
         transform cria novo "containing block" para position:fixed →
         pickers de emote/sticker ficam contidos aqui */
      #dlive-theater-chat-slot {
        flex: 0 0 360px !important;
        width: 360px !important;
        height: 100% !important;
        background: #131313 !important;
        border-left: 1px solid #1e1e1e !important;
        display: flex !important;
        flex-direction: column !important;
        overflow: hidden !important;
        position: relative !important;
        transform: translateZ(0) !important;
        will-change: transform !important;
        color-scheme: dark !important;
      }

      /* ── Cabeçalho do chat ── */
      #dlive-theater-chat-header {
        flex-shrink: 0 !important;
        height: 34px !important;
        padding: 0 14px !important;
        background: #0f0f0f !important;
        border-bottom: 1px solid #1e1e1e !important;
        display: flex !important;
        align-items: center !important;
        gap: 7px !important;
        font: 700 10px/1 'Segoe UI', system-ui, sans-serif !important;
        color: #f6c90e !important;
        letter-spacing: 1.3px !important;
        text-transform: uppercase !important;
        box-sizing: border-box !important;
      }

      /* ── Container do chat movido ──
         Apenas dimensões — não interferimos no layout Vue */
      #dlive-theater-chat-slot [data-theater-chat="true"] {
        flex: 1 1 auto !important;
        min-height: 0 !important;
        width: 360px !important;
        max-width: 360px !important;
        height: calc(100vh - 34px) !important;
        max-height: calc(100vh - 34px) !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        /* cor base — evita texto preto herdado */
        color: #e0e0e0 !important;
      }

      /* ── Correção de cores ──
         DLive é dark theme. Ao mover o chat, alguns elementos
         herdam color: black do :root padrão do sistema. */
      #dlive-theater-chat-slot {
        color: #e0e0e0 !important;
      }

      /* Inputs/textareas legíveis */
      #dlive-theater-chat-slot input,
      #dlive-theater-chat-slot textarea,
      #dlive-theater-chat-slot [contenteditable="true"],
      #dlive-theater-chat-slot [contenteditable=""] {
        color: #e0e0e0 !important;
        background-color: #1e1e1e !important;
        caret-color: #f6c90e !important;
      }
      #dlive-theater-chat-slot input::placeholder,
      #dlive-theater-chat-slot textarea::placeholder {
        color: #555 !important;
      }
      #dlive-theater-chat-slot button {
        color: inherit !important;
      }

      /* ── Imagens no chat ──
         Usamos overflow:hidden no slot para conter qualquer imagem
         que quebre o layout. Não tentamos adivinhar classes do picker.
         Apenas impedimos que imagens MUITO grandes estourem. */
      #dlive-theater-chat-slot img {
        max-width: 100% !important;
        height: auto !important;
        display: inline-block !important;
        vertical-align: middle !important;
      }

      /* GIFs/stickers enviados no chat: limita a 160px */
      #dlive-theater-chat-slot img[src$=".gif"],
      #dlive-theater-chat-slot img[src*=".gif?"] {
        max-width: 160px !important;
        max-height: 160px !important;
        border-radius: 4px !important;
      }

      /* Emotes/emojis: tamanho normalizado via JS (watchEmotes)
         apenas nas mensagens do chat, não no picker */

      /* ── Links: não expandem o container ── */
      #dlive-theater-chat-slot a {
        word-break: break-all !important;
        overflow-wrap: break-word !important;
        max-width: 100% !important;
        display: inline !important;
        color: #7bb3f0 !important;
      }
      #dlive-theater-chat-slot a:hover { color: #a8d0f8 !important; }

      /* ── Descrição do canal: oculta quando sobrepõe o overlay ──
         O DLive renderiza a descrição num container abaixo do player
         que fica com z-index alto e invade o chat no modo teatro.
         Garantimos que qualquer coisa fora do overlay fique invisível,
         e reforçamos com seletores específicos. */
      body.dlive-theater-mode [class*="description" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="Description"]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="stream-info" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="StreamInfo"]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="channel-info" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="ChannelInfo"]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="about" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="panel" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="Panel"]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="below" i]:not(#dlive-theater-overlay *),
      body.dlive-theater-mode [class*="meta" i]:not(#dlive-theater-overlay *) {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
        z-index: -1 !important;
      }

      /* Garante que o overlay fique SEMPRE acima de qualquer z-index do site */
      #dlive-theater-overlay {
        z-index: 2147483600 !important;
      }

      /* ── Cards de preview de URL: ocultamos ──
         Expandem o chat e redirecionam para imagens */
      #dlive-theater-chat-slot [class*="link-preview" i],
      #dlive-theater-chat-slot [class*="LinkPreview"],
      #dlive-theater-chat-slot [class*="url-preview" i],
      #dlive-theater-chat-slot [class*="og-card" i],
      #dlive-theater-chat-slot [class*="embed-card" i],
      #dlive-theater-chat-slot [class*="media-preview" i] {
        display: none !important;
      }

      /* ── Picker de emotes/stickers ──
         NÃO aplicamos nenhuma regra de tamanho ou layout aqui.
         O DLive gerencia seu próprio picker — só garantimos que
         ele não vaze para fora do slot via overflow:hidden no slot. */

      /* ── Scrollbars ── */
      #dlive-theater-chat-slot ::-webkit-scrollbar { width: 3px !important; }
      #dlive-theater-chat-slot ::-webkit-scrollbar-track { background: transparent !important; }
      #dlive-theater-chat-slot ::-webkit-scrollbar-thumb {
        background: #2e2e2e !important;
        border-radius: 2px !important;
      }

      /* ── Botão sair ── */
      #dlive-theater-exit {
        position: fixed !important;
        top: 14px !important;
        left: 50% !important;
        transform: translateX(-50%) translateY(-8px) !important;
        z-index: 2147483647 !important;
        background: rgba(8,8,8,0.92) !important;
        border: 1px solid rgba(246,201,14,0.4) !important;
        color: #f6c90e !important;
        font: 700 11px/1 'Segoe UI', system-ui, sans-serif !important;
        letter-spacing: 1.5px !important;
        padding: 7px 22px !important;
        border-radius: 20px !important;
        cursor: pointer !important;
        opacity: 0 !important;
        transition: opacity .25s ease, transform .25s ease !important;
        backdrop-filter: blur(12px) !important;
        white-space: nowrap !important;
        visibility: visible !important;
        pointer-events: all !important;
      }
      body.theater-show-exit #dlive-theater-exit,
      #dlive-theater-exit:hover {
        opacity: 1 !important;
        transform: translateX(-50%) translateY(0) !important;
      }

      /* ── Toast ── */
      #dlive-theater-notif {
        position: fixed !important;
        bottom: 22px !important;
        left: 50% !important;
        transform: translateX(-50%) translateY(8px) !important;
        z-index: 2147483647 !important;
        background: #161616 !important;
        font: 600 12px/1 'Segoe UI', system-ui, sans-serif !important;
        padding: 9px 22px !important;
        border-radius: 20px !important;
        pointer-events: none !important;
        opacity: 0 !important;
        transition: opacity .3s ease, transform .3s ease !important;
        visibility: visible !important;
      }
    `;
    document.head.appendChild(styleEl);
  }

  // ─── Corrige cores computadas pós-move ────────────────────
  function fixColors(chatEl) {
    if (!chatEl) return;
    setTimeout(() => {
      if (!theaterActive) return;
      let n = 0;
      chatEl.querySelectorAll('*').forEach(el => {
        const t = el.tagName?.toLowerCase();
        if (['img','video','canvas','svg','iframe'].includes(t)) return;
        if (el.style.color) return; // respeita cor inline
        const cs = window.getComputedStyle(el);
        const cRgb = parseRgb(cs.color);
        const bRgb = parseRgb(cs.backgroundColor);
        if (!cRgb) return;
        const cL = lum(cRgb), bL = bRgb ? lum(bRgb) : 0;
        // Texto muito escuro + fundo escuro → invisível
        if (cL < 0.05 && bL < 0.15) {
          el.style.setProperty('color', '#d0d0d0', 'important');
          n++;
        }
        // Fundo claro dentro do chat
        if (bRgb && bL > 0.7 && cs.backgroundColor !== 'rgba(0, 0, 0, 0)') {
          el.style.setProperty('background-color', '#1a1a1a', 'important');
          if (cL > 0.7) el.style.setProperty('color', '#d0d0d0', 'important');
          n++;
        }
      });
      log('fixColors:', n, 'elementos corrigidos');
    }, 800);
  }

  // Observa novas mensagens e corrige cores ao entrar
  function watchColors(chatEl) {
    if (!chatEl) return;
    colorFixObserver?.disconnect();
    colorFixObserver = new MutationObserver(mutations => {
      if (!theaterActive) return;
      mutations.forEach(m => m.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        [node, ...node.querySelectorAll('*')].forEach(el => {
          const t = el.tagName?.toLowerCase();
          if (['img','video','canvas','svg','iframe'].includes(t)) return;
          if (el.style.color) return;
          const cs = window.getComputedStyle(el);
          const cRgb = parseRgb(cs.color);
          const bRgb = parseRgb(cs.backgroundColor);
          if (cRgb && lum(cRgb) < 0.05 && (!bRgb || lum(bRgb) < 0.15)) {
            el.style.setProperty('color', '#d0d0d0', 'important');
          }
        });
      }));
    });
    colorFixObserver.observe(chatEl, { childList: true, subtree: true });
  }

  function parseRgb(c) {
    const m = c?.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    return m ? [+m[1], +m[2], +m[3]] : null;
  }
  function lum([r, g, b]) { return (0.299*r + 0.587*g + 0.114*b) / 255; }

  // ─── Normaliza emotes a 64x64 SOMENTE nas mensagens ────────
  // Detecta se uma imagem está dentro de uma mensagem de chat
  // (tem texto irmão ou pai com texto) e não dentro do picker.
  let emoteObserver = null;

  function isInsidePicker(img) {
    let el = img.parentElement;
    const chatSlot = document.getElementById('dlive-theater-chat-slot');
    while (el && el !== chatSlot) {
      const cls = (el.className || '').toString().toLowerCase();
      if (
        cls.includes('picker')           ||
        cls.includes('emote-list')       ||
        cls.includes('sticker-list')     ||
        cls.includes('emoji-list')       ||
        cls.includes('tab-content')      ||
        cls.includes('tab-panel')        ||
        cls.includes('emote-grid')       ||
        cls.includes('grid')             ||
        cls.includes('emote-tab-inner')  ||  // classe real do DLive
        cls.includes('emoji-emote-wrapper') || // wrapper do emote no picker
        cls.includes('flex-wrap')        ||  // container do grid de emotes
        cls.includes('tab-inner')
      ) return true;

      // Heurística: container com muitas imagens e pouco texto = picker
      const imgCount = el.querySelectorAll('img').length;
      const textLen  = (el.innerText || '').replace(/\s/g, '').length;
      if (imgCount >= 4 && textLen < 20) return true;

      el = el.parentElement;
    }
    return false;
  }

  function applyEmoteSize(img) {
    if (isInsidePicker(img)) return; // está no picker, não toca
    img.style.setProperty('width',        '64px',    'important');
    img.style.setProperty('height',       '64px',    'important');
    img.style.setProperty('max-width',    '64px',    'important');
    img.style.setProperty('max-height',   '64px',    'important');
    img.style.setProperty('min-width',    '64px',    'important');
    img.style.setProperty('min-height',   '64px',    'important');
    img.style.setProperty('object-fit',   'contain', 'important');
    img.style.setProperty('vertical-align','middle', 'important');
  }

  function watchEmotes(chatEl) {
    if (!chatEl) return;
    emoteObserver?.disconnect();

    // Aplica nas imagens já presentes no chat
    chatEl.querySelectorAll('img.emoji-img, img.clickable').forEach(applyEmoteSize);

    emoteObserver = new MutationObserver(mutations => {
      if (!theaterActive) return;
      mutations.forEach(m => m.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        const imgs = node.matches?.('img.emoji-img, img.clickable')
          ? [node]
          : [...node.querySelectorAll('img.emoji-img, img.clickable')];
        imgs.forEach(img => {
          // Pequeno delay para o DOM estabilizar antes de checar picker
          requestAnimationFrame(() => applyEmoteSize(img));
        });
      }));
    });
    emoteObserver.observe(chatEl, { childList: true, subtree: true });
  }

  // ─── Ativa ────────────────────────────────────────────────
  async function activateTheater() {
    if (theaterActive) return;
    log('Ativando...');
    showNotification('⏳ Procurando player e chat…', '#888');

    let playerEl;
    try {
      playerEl = await waitFor(findPlayerEl, 8000);
    } catch (_) {
      showNotification('❌ Player não encontrado', '#f66');
      return;
    }

    const chatEl = findChatEl();
    theaterActive = true;

    injectCSS();

    overlayEl = document.createElement('div');
    overlayEl.id = 'dlive-theater-overlay';

    const pSlot = document.createElement('div');
    pSlot.id = 'dlive-theater-player-slot';

    const cSlot = document.createElement('div');
    cSlot.id = 'dlive-theater-chat-slot';

    const cHead = document.createElement('div');
    cHead.id = 'dlive-theater-chat-header';
    cHead.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
    </svg> Chat ao Vivo`;
    cSlot.appendChild(cHead);

    overlayEl.appendChild(pSlot);
    overlayEl.appendChild(cSlot);
    document.body.appendChild(overlayEl);

    // Move player
    playerEl.dataset.theaterPlayer = 'true';
    playerEl._origParent = playerEl.parentElement;
    playerEl._origNext   = playerEl.nextSibling;
    playerEl.dataset.origStyle = playerEl.getAttribute('style') || '';
    pSlot.appendChild(playerEl);

    // Move chat
    if (chatEl) {
      chatEl.dataset.theaterChat = 'true';
      chatEl._origParent = chatEl.parentElement;
      chatEl._origNext   = chatEl.nextSibling;
      chatEl.dataset.origStyle = chatEl.getAttribute('style') || '';
      cSlot.appendChild(chatEl);
      fixColors(chatEl);
      watchColors(chatEl);
      watchEmotes(chatEl);
    } else {
      const d = document.createElement('div');
      d.style.cssText = 'padding:20px;color:#444;font:12px Segoe UI,sans-serif;line-height:1.7';
      d.textContent = 'Chat não detectado nesta página.';
      cSlot.appendChild(d);
    }

    document.body.classList.add('dlive-theater-mode');

    // Botão sair
    exitBtn = document.createElement('button');
    exitBtn.id = 'dlive-theater-exit';
    exitBtn.textContent = '✕  SAIR DO TEATRO';
    exitBtn.onclick = deactivateTheater;
    document.body.appendChild(exitBtn);

    let hT;
    pSlot.addEventListener('mousemove', () => {
      document.body.classList.add('theater-show-exit');
      clearTimeout(hT);
      hT = setTimeout(() => document.body.classList.remove('theater-show-exit'), 2500);
    });
    exitBtn.addEventListener('mouseenter', () => {
      clearTimeout(hT);
      document.body.classList.add('theater-show-exit');
    });

    document.addEventListener('keydown', onEsc);
    watchSPA();

    chrome.storage.local.set({ [STORAGE_KEY]: true });
    showNotification('🎬  Modo Teatro Ativado — ESC para sair', '#f6c90e');
    log('Ativado! Player:', playerEl.tagName, '| Chat:', chatEl?.tagName ?? 'não encontrado');

    // Pós-ativação: oculta elementos intrusos (descrição do canal etc)
    setTimeout(hideIntruders, 300);
    setTimeout(hideIntruders, 1500);
  }

  // ─── Rastreia elementos modificados pelo hideIntruders ───
  const _hiddenByTheater = new Set();

  // ─── Oculta elementos que invadem o overlay ───────────────
  function hideIntruders() {
    if (!theaterActive) return;
    const overlay = document.getElementById('dlive-theater-overlay');
    if (!overlay) return;

    // Filhos diretos do body fora do overlay — reforça via style inline
    document.querySelectorAll(
      'body > *:not(#dlive-theater-overlay):not(#dlive-theater-exit):not(#dlive-theater-notif)'
    ).forEach(el => {
      if (!_hiddenByTheater.has(el)) {
        el._theaterOrigVis = el.style.visibility || '';
        el._theaterOrigPE  = el.style.pointerEvents || '';
        _hiddenByTheater.add(el);
      }
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
    });

    // Elementos intrusos com position:fixed ou z-index alto
    const intrusive = [
      '[class*="description" i]', '[class*="stream-info" i]',
      '[class*="about-panel" i]', '[class*="channel-panel" i]',
      '[class*="panels" i]', '[class*="below-player" i]',
    ];
    intrusive.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        if (overlay.contains(el)) return;
        const cs = window.getComputedStyle(el);
        if (cs.position === 'fixed' || cs.position === 'sticky' || (parseInt(cs.zIndex) || 0) > 100) {
          if (!_hiddenByTheater.has(el)) {
            el._theaterOrigDisplay = el.style.display || '';
            _hiddenByTheater.add(el);
          }
          el.style.setProperty('display', 'none', 'important');
        }
      });
    });
  }

  // ─── Restaura os elementos ocultados pelo hideIntruders ───
  function restoreIntruders() {
    _hiddenByTheater.forEach(el => {
      if (el._theaterOrigDisplay !== undefined) {
        if (el._theaterOrigDisplay) el.style.display = el._theaterOrigDisplay;
        else el.style.removeProperty('display');
        delete el._theaterOrigDisplay;
      }
      if (el._theaterOrigVis !== undefined) {
        if (el._theaterOrigVis) el.style.visibility = el._theaterOrigVis;
        else el.style.removeProperty('visibility');
        delete el._theaterOrigVis;
      }
      if (el._theaterOrigPE !== undefined) {
        if (el._theaterOrigPE) el.style.pointerEvents = el._theaterOrigPE;
        else el.style.removeProperty('pointer-events');
        delete el._theaterOrigPE;
      }
    });
    _hiddenByTheater.clear();
  }

  // ─── Desativa ─────────────────────────────────────────────
  function deactivateTheater() {
    if (!theaterActive) return;
    theaterActive = false;

    document.body.classList.remove('dlive-theater-mode', 'theater-show-exit');

    restoreIntruders();
    restore('[data-theater-player="true"]');
    restore('[data-theater-chat="true"]');

    overlayEl?.remove(); overlayEl = null;
    exitBtn?.remove();   exitBtn = null;
    styleEl?.remove();   styleEl = null;
    mutObserver?.disconnect();      mutObserver = null;
    colorFixObserver?.disconnect(); colorFixObserver = null;
    emoteObserver?.disconnect();    emoteObserver = null;
    clearTimeout(retryTimer);

    document.removeEventListener('keydown', onEsc);
    chrome.storage.local.set({ [STORAGE_KEY]: false });
    showNotification('Modo Teatro Desativado', '#555');
    log('Desativado.');
  }

  function restore(sel) {
    const el = document.querySelector(sel);
    if (!el) return;
    const p = el._origParent, n = el._origNext;
    if (p) {
      if (n && p.contains(n)) p.insertBefore(el, n);
      else p.appendChild(el);
    }
    const s = el.dataset.origStyle || '';
    if (s) el.setAttribute('style', s); else el.removeAttribute('style');
    delete el.dataset.origStyle;
    delete el._origParent;
    delete el._origNext;
    // Remove atributos de marcação
    delete el.dataset.theaterPlayer;
    delete el.dataset.theaterChat;
  }

  function toggleTheater() { theaterActive ? deactivateTheater() : activateTheater(); }
  function onEsc(e) { if (e.key === 'Escape') deactivateTheater(); }

  function watchSPA() {
    mutObserver?.disconnect();
    mutObserver = new MutationObserver(() => {
      if (!theaterActive) return;
      const slot = document.getElementById('dlive-theater-player-slot');
      if (slot && !slot.querySelector('video')) {
        clearTimeout(retryTimer);
        retryTimer = setTimeout(() => {
          if (!theaterActive) return;
          const p = findPlayerEl();
          if (p && !p.dataset.theaterPlayer) {
            p.dataset.theaterPlayer = 'true';
            p._origParent = p.parentElement;
            p._origNext   = p.nextSibling;
            slot.appendChild(p);
            log('Player redetectado.');
          }
        }, 1500);
      }
    });
    mutObserver.observe(document.body, { childList: true, subtree: true });
  }

  function showNotification(msg, color = '#f6c90e') {
    let n = document.getElementById('dlive-theater-notif');
    if (!n) { n = document.createElement('div'); n.id = 'dlive-theater-notif'; document.body.appendChild(n); }
    n.style.color = color;
    n.style.border = `1px solid ${color}44`;
    n.textContent = msg;
    n.style.opacity = '0';
    n.style.transform = 'translateX(-50%) translateY(8px)';
    void n.offsetHeight;
    n.style.opacity = '1';
    n.style.transform = 'translateX(-50%) translateY(0)';
    clearTimeout(n._t);
    n._t = setTimeout(() => { n.style.opacity='0'; n.style.transform='translateX(-50%) translateY(8px)'; }, 3000);
  }

  chrome.runtime.onMessage.addListener((msg, _, res) => {
    if (msg.action === 'toggleTheater') { toggleTheater(); res({ active: theaterActive }); }
    else if (msg.action === 'getStatus') { res({ active: theaterActive }); }
    else if (msg.action === 'getDiagnostics') {
      const p = findPlayerEl(), c = findChatEl();
      res({
        active: theaterActive,
        hasVideo: !!document.querySelector('video'),
        playerEl: p ? `${p.tagName}.${p.className?.toString().slice(0,80)}` : 'não encontrado',
        chatEl:   c ? `${c.tagName}.${c.className?.toString().slice(0,80)}` : 'não encontrado',
        url: location.href,
      });
    }
    return true;
  });

  chrome.storage.local.get([STORAGE_KEY], r => {
    if (r[STORAGE_KEY]) {
      const go = () => setTimeout(activateTheater, 1200);
      document.readyState === 'complete' ? go() : window.addEventListener('load', go);
    }
  });

})();
