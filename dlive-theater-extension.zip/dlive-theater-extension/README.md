# 🎬 DLive Ultra Theater v2

Extensão Chrome para modo teatro aprimorado no DLive.tv.

**Mudança principal na v2:** O player e o chat são **movidos** para o overlay (não clonados). Isso resolve:
- Tela preta do vídeo (HLS/MediaSource não pode ser copiado)
- Chat quebrado (WebSocket perde conexão ao clonar)

---

## 📦 Instalação

1. Extraia o ZIP
2. Chrome → `chrome://extensions/`
3. Ative **Modo do Desenvolvedor**
4. **Carregar sem compactação** → selecione a pasta
5. Ícone aparece na barra do Chrome ✅

---

## 🚀 Uso

1. Acesse uma transmissão ao vivo no **dlive.tv**
2. Clique no ícone da extensão → **▶ ATIVAR MODO TEATRO**
3. Pressione **ESC** ou clique no botão flutuante para sair

---

## 🔍 Debug

Se algo não funcionar, clique em **"Diagnóstico"** no popup.  
Ele mostra: se o vídeo foi detectado, a classe do player, a classe do chat, etc.

Você também pode abrir o Console do Chrome (F12) na aba do DLive e ver os logs `[DLive Theater]`.

---

## 📁 Arquivos

```
dlive-theater-extension/
├── manifest.json
├── content.js     ← lógica principal (move elementos)
├── popup.html
├── popup.js
└── icons/
```
